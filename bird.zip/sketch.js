function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
 arc(150, 200, 80, 80, radians(190), radians(340));
  arc(227, 200, 80, 80, radians(190), radians(340));
  noFill();
}