function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  function head(){
  circle(150, 200, 70);
  
    function eyes(){
    stroke('green');
    strokeWeight(10);
    
    point(170, 200);
    point(150, 200);
    stroke('black');
    strokeWeight(1);  
    }
    eyes();}
  
   function ears(){
    line(118, 184, 111, 137);
    line(111, 137, 144, 165);
    line(144, 165, 177, 147);
    line(177, 146, 190, 160);
    line(190, 160, 177, 166);
    line(177, 167, 177, 177);}
  
  head();
  ears();
 
  text("(" + mouseX + ", " + mouseY + ")", mouseX, mouseY);
  stroke(0);
  noFill();
  
}